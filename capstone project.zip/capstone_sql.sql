-- SQL

-- Use MySQL or PyMySQL to perform the below queries. 

-- Note: Use only the cleaned data for SQL part of the project


-- 1.Group the customers based on their income type and find the average of their annual income.

-- 2. Find the female owners of cars and property.

-- 3.Find the male customers who are staying with their families.

-- 4.Please list the top five people having the highest income.

-- 5.How many married people are having bad credit?

-- 6.What is the highest education level and what is the total count?

-- Between married males and females, who is having more bad credit? 




-- 1.Group the customers based on their income type and find the average of their annual income. ## 4
select * from credit_card_final;
select Type_Income, avg(Annual_income) from credit_card_final
group by Type_Income;

-- -- 2. Find the female owners of cars and property. ## 170
select * from credit_card_final
where GENDER = "F" and Car_Owner="Y" and Propert_Owner="Y";

-- 3.Find the male customers who are staying with their families. 
select * from credit_card_final
where GENDER = "M" and Family_Members>1;
# 438 members are staying with there family

-- 4.Please list the top five people having the highest income.
select distinct Annual_income from credit_card_final
order by Annual_income desc limit 5 ;
## 5 rows


-- 5.How many married people are having bad credit?
select * from credit_card_final
where Marital_status="Married" and label=0;
## 898 rows

-- 6.What is the highest education level and what is the total count?
select EDUCATION, count(*) as total_count from credit_card_final
group by EDUCATION order by EDUCATION asc limit 1;
## Academic Degree-2


-- 7.Between married males and females, who is having more bad credit?
select GENDER,count(*) from credit_card_final
where Marital_status="Married" and label=0 group by GENDER

## female having bad credit as compare to male




